//
//  LoginViewController.h
//  LoveBird
//
//  Created by 廖冠翰 on 2016/12/25.
//  Copyright © 2016年 yu hasing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@end
