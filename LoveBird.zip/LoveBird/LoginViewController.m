//
//  LoginViewController.m
//  LoveBird
//
//  Created by 廖冠翰 on 2016/12/25.
//  Copyright © 2016年 yu hasing. All rights reserved.
//

#import "LoginViewController.h"
@import Firebase;               //firebase
@import FirebaseDatabase;  //firebase
@interface LoginViewController ()<UITextFieldDelegate>{
NSMutableDictionary *postDict;
}
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UITextField *accounttext;
@property (weak, nonatomic) IBOutlet UITextField *passwordtext;
@property (strong, nonatomic) FIRDatabaseReference *ref;
@end

@implementation LoginViewController

#pragma mark - Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];

    
//    _ref=[[FIRDatabase database] reference];  firebase
//    
//    [_ref observeEventType:FIRDataEventTypeValue withBlock:^(FIRDataSnapshot * _Nonnull snapshot) {
//        
//        postDict = snapshot.value;
//        NSLog(@"%@",postDict);
//        [_tableView reloadData];
//        
//    }];
}

#pragma mark - UI Init
- (void)initUI{
    [self setupLoginButton];
}

- (void)setupLoginButton{
    [self.loginButton.layer setCornerRadius:5.0];
    [self.loginButton.layer setMasksToBounds:YES];
}

//#pragma mark - UITextFieldDelegate
//- (BOOL)textFieldShouldReturn:(UITextField *)textField{
//    
//    [textField resignFirstResponder];
//    
//    return YES;
//}

#pragma mark - Event Handler

- (IBAction)loginButtonClick {
   
//    [[FIRAuth auth] signInWithEmail:_accounttext.text
//                           password:_passwordtext.text
//                         completion:^(FIRUser *user, NSError *error) {
//                             // ...
//                             
//                             if (error != nil){
//                                 NSString *errorMessage = error.localizedDescription;
//                                 
//                                 UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:errorMessage preferredStyle: UIAlertControllerStyleAlert];
//                                 
//                                 [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//                                 }]];
//                                 //提示框；
//                                 [self presentViewController:alert animated:true completion:nil];
//                             }else {
//                                 NSLog(@"Login Sucess");
// [self goMain];
//                             }
//                             _accounttext.text = nil;
//                             _passwordtext.text = nil;
//                         }];
    [self goMain];
}


#pragma mark - Class Medthod
- (void)goMain{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Main"];
    [self presentViewController:vc animated:YES completion:nil];
}
@end
