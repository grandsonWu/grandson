//
//  NoteViewController.h
//  LoveBird
//
//  Created by User on 2016/11/29.
//  Copyright © 2016年 yu hasing. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NoteViewController : UIViewController

@end
