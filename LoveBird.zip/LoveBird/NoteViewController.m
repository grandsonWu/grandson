//
//  NoteViewController.m
//  LoveBird
//
//  Created by User on 2016/11/29.
//  Copyright © 2016年 yu hasing. All rights reserved.
//
#import "SecondNoteViewController.h"
#import "NoteViewController.h"
#import "Note.h"
@interface NoteViewController ()<UITableViewDelegate,UITableViewDataSource,SecondNoteViewControllerDelegate>{
    NSMutableArray *notes;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation NoteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [self.tableView reloadData];
}

-(void)setEditing:(BOOL)editing animated:(BOOL)animated{
    [super setEditing: editing animated:animated];
    [self.tableView setEditing:editing animated:animated];
    
}
- (id)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        notes = [NSMutableArray array];
        for (int i = 0; i < 5 ; i++)  {
            Note *note = [[Note alloc]init];
            note.content = [NSString stringWithFormat:@"   %d" , i];
            [notes addObject:note];
        }
    }
    return self;
}

- (IBAction)add:(id)sender {
    Note *note = [[Note alloc]init];
    note.content =[NSString stringWithFormat:@"請寫下.... %ld",notes.count];
    [notes addObject:note];
    [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:notes.count-1 inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return notes.count;
    };

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"basic" forIndexPath:indexPath];
    Note * note =[notes objectAtIndex:indexPath.row];
    cell.showsReorderControl= YES;
    cell.imageView.image=[note profileImage];
    cell.textLabel.text=note.content;
       return cell;
}
-(void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath{
    Note * note = notes[sourceIndexPath.row];//使用者點到哪筆資料
    [notes removeObjectAtIndex:sourceIndexPath.row];//在陣列裡無法移動必須先移除
    [notes insertObject:note atIndex:destinationIndexPath.row];//在新增
    [tableView moveRowAtIndexPath:sourceIndexPath toIndexPath:destinationIndexPath];//從source 移到 destinationindexPath
    
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if(editingStyle==UITableViewCellEditingStyleDelete) {
        [notes removeObjectAtIndex:indexPath.row];
        [tableView  deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    SecondNoteViewController *noteviewcontroller=[self.storyboard instantiateViewControllerWithIdentifier:@"noteviewcontroller"];
    Note *note =notes[tableView.indexPathForSelectedRow.row];
    noteviewcontroller.currentNote = note;
    noteviewcontroller.delegate = self;
    //以上為不用拉線也可以連接viewcontroller的方法
    
    [self.navigationController pushViewController:noteviewcontroller animated:YES];//會將下一層的view放上來這一層檢視
}

#pragma mark - SecondNoteViewControllerDelegate

- (void)secondNoteViewControllerReloadData{
    [self.tableView reloadData];
}


//#pragma mark - prepareForSegue
//-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
//    
//    if( [segue.identifier isEqualToString:@"detail"]){
//        SecondNoteViewController *secondNoteController = segue.destinationViewController;
//        secondNoteController.delegate = self;
//    }
//}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
