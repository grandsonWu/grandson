//
//  GreatUserViewController.h
//  LoveBird
//
//  Created by User on 2017/1/5.
//  Copyright © 2017年 yu hasing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GreatUserViewController : UIViewController

@end
