//
//  GreatUserViewController.m
//  LoveBird
//
//  Created by User on 2017/1/5.
//  Copyright © 2017年 yu hasing. All rights reserved.
//

#import "GreatUserViewController.h"

@interface GreatUserViewController ()
@property (weak, nonatomic) IBOutlet UITextField *creataccountText;
@property (weak, nonatomic) IBOutlet UITextField *creatPasswordText;
@property (weak, nonatomic) IBOutlet UITextField *passwordConfirmText;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;

@end

@implementation GreatUserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)creatAccountBtn:(id)sender {
}

- (IBAction)cleanBtn:(id)sender {
}

- (IBAction)cancelBtn:(id)sender {
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
