//
//  MyBezierPath.h
//  LoveBird
//
//  Created by User on 2017/1/3.
//  Copyright © 2017年 yu hasing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBezierPath : UIBezierPath
@property (nonatomic,strong) UIColor *color;  //當前路徑的顏色

@end
